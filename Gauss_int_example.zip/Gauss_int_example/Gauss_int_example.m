%----------------------------------------------------------------------------                                                            
%   Gauss-Legendre quadrature of a function in 2-dimension
%                                                                            
% Problem description                                                        
%   Integrate f(x,y)=1+4xy-3x^2y^2+x^4y^6 over -1<x<1 and -1<y<1          
%                                                                            
% Variable descriptions                                                      
%   point2 = integration (or sampling) points                                             
%   weight2 = weighting coefficients                                             
%   nglx = number of integration points along x-axis                                                
%   ngly = number of integration points along y-axis
%----------------------------------------------------------------------------%           
clear
nglx=2;         
ngly=2;           
[point2,weight2]=gauss_integration(nglx,ngly);  % integration points and weights

isoparametric = 0;
% x1 = 2; x2 = 11; x3 = 11; x4 = 2; 
% y1 = 7; y2 = 7; y3 = 19; y4 = 19;
% x1 = 0; x2 = 1; x3 = 1; x4 = 0; 
% y1 = 0; y2 = 0; y3 = 1; y4 = 1;
x1 = -1; x2 = 1; x3 = 1.; x4 = -1; 
y1 = -1; y2 = -1; y3 = 1; y4 = 1;
value=0.0;
for intx=1:nglx
    sai=point2(intx,1);  % sampling point in x-axis
    wtx=weight2(intx,1); % weight in x-axis
    for inty=1:ngly
        eta=point2(inty,2); % sampling point in y-axis
        wty=weight2(inty,2) ;% weight in y-axis
        if isoparametric == 0  % meaning it is not isoparametric; must be -1 1
            x=sai;
            y=eta;
            func = x^2+y;
            value=value+func*wtx*wty;      
        %Using isoparametric form so any dimensions can be given
        % b/c we map to intrinsic coordinates -1 to 1
        else 
            N1 = .25*(1-sai)*(1-eta); 
            N2 = .25*(1+sai)*(1-eta);
            N3 = .25*(1+sai)*(1+eta); 
            N4 = .25*(1-sai)*(1+eta);
            TJ11 = ((1 - eta) * (x2 - x1) + (1 + eta) * (x3 - x4)) / 4;
            TJ12 = ((1 - eta) * (y2 - y1) + (1 + eta) * (y3 - y4)) / 4;
            TJ21 = ((1 - sai) * (x4 - x1) + (1 + sai) * (x3 - x2)) / 4;
            TJ22 = ((1 - sai) * (y4 - y1) + (1 + sai) * (y3 - y2)) / 4;
            detJ = TJ11 * TJ22 - TJ12 * TJ21;
            x = N1*x1 + N2*x2 + N3*x3 + N4*x4; 
            y = N1*y1 + N2*y2 + N3*y3 + N4*y4;
            %func=x^3+x^4*y^5;    % evaluate function at sampling points
            func = x^2+y;
            value=value+func*detJ*wtx*wty;
        end
    end
end

value                    % print the solution
%theoretical = 1259389717443/5. %from mathematica output
%percent_error = abs(value - theoretical)/theoretical*100

%-----------------------------------------------------------------

